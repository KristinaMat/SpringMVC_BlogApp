package lt.kristina.blogapp.controller;

import lombok.AllArgsConstructor;
import lt.kristina.blogapp.errors.CommentNotFoundException;

import lt.kristina.blogapp.model.Comment;

import lt.kristina.blogapp.model.User;
import lt.kristina.blogapp.service.CommentsService;
import lt.kristina.blogapp.service.PostsService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.security.Principal;
import java.util.UUID;

@AllArgsConstructor
@Controller
public class CommentsController {
    private final PostsService postsService;
    private final CommentsService commentsService;

    @GetMapping("/comments")
    public String getComments(@PageableDefault(size = 4) Pageable pageable, Model model, Principal principal,
                              Authentication authentication, @AuthenticationPrincipal User user ) {

        SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Page<Comment> comments = commentsService.getComments(pageable);
        model.addAttribute("comments", comments);

        return "comments";
    }

    @GetMapping("/comments/create")
    public String openCommentForm(Model model) {

        model.addAttribute("comment", new Comment());
        return "commentForm";
    }

    @PostMapping("/comments/create")
    public String createComment(@Valid Comment comment, BindingResult errors, RedirectAttributes redirectAttributes) {

        if(errors.hasErrors()){
            return "commentForm";
        }
        commentsService.createComment(comment);

        redirectAttributes.addFlashAttribute("message",
                String.format("Comment '%s' successfully created!", comment.getId()));

        return "redirect:/comments";
    }
    @GetMapping("/comments/{id}")
    public String openComment(@PathVariable UUID id, Model model) {

        model.addAttribute("comment", commentsService.getComment(id));

        return "commentForm";
    }

    @PostMapping("/comments/{id}")
    public String updateComment(Comment comment, Model model) {

        commentsService.updateComment(comment);

        model.addAttribute("message", String.format("Comment '%s' successfully updated!", comment.getId()));

        return "redirect:/comments";
    }

    @PostMapping("/comments/{id}/delete")
    public String deleteComment(@PathVariable UUID id, RedirectAttributes redirectAttributes) {

        Comment comment = commentsService.deleteComment(id);

        redirectAttributes.addAttribute("message", String.format("Comment '%s' successfully deleted!", comment.getId()));

        return "redirect:/comments";
    }


    @ExceptionHandler(CommentNotFoundException.class)
    public String CommentNotFound(CommentNotFoundException e, Model model) {

        model.addAttribute("messageCode", e.getMessage());
        model.addAttribute("commentId", e.getCommentId());

        return "error/commentNotFoundPage";
    }

}
