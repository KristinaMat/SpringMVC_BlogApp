package lt.kristina.blogapp.errors;


import lombok.Getter;

import java.util.UUID;

@Getter
public class PostNotFoundException extends RuntimeException {
    private final UUID postId;

    public PostNotFoundException(String messageCode, UUID postId) {
        super(messageCode);
        this.postId = postId;
    }

}
