package lt.kristina.blogapp.errors;

import lombok.Getter;

import java.util.UUID;

@Getter
public class CommentNotFoundException extends RuntimeException{
    private final UUID commentId;

    public CommentNotFoundException(String messageCode, UUID commentId) {
        super(messageCode);
        this.commentId =commentId;
    }
}
