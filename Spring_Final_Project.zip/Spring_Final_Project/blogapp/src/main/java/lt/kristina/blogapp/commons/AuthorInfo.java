package lt.kristina.blogapp.commons;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
@ConfigurationProperties(prefix = "author")
public class AuthorInfo {
    private String name;
    private String surname;
    private Long data;
}
