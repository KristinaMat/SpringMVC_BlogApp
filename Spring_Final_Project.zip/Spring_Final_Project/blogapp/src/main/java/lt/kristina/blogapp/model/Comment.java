package lt.kristina.blogapp.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
public class Comment {
    @Id
    @Type(type = "uuid-char")
    private UUID id;

    @NotNull
    @Size(max=255)
    private String body;


    @ManyToOne
    @JoinColumn(name="post_id")
    private Post post;



}
