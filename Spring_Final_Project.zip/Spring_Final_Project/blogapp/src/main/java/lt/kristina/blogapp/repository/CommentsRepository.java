package lt.kristina.blogapp.repository;

import lt.kristina.blogapp.model.Comment;
import lt.kristina.blogapp.model.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface CommentsRepository extends JpaRepository<Comment, UUID> {

    Page<Comment> findAll(Pageable pageable);

    Comment save(Comment comment);

    Optional<Comment> findById(UUID id);

    void delete(Comment commentToRemove);
}
