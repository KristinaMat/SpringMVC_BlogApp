package lt.kristina.blogapp.commons.controlleradvice;

import lt.kristina.blogapp.commons.AuthorInfo;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class AuthorInfoControllerAdvice {
    private final AuthorInfo authorInfo;

    public AuthorInfoControllerAdvice(AuthorInfo authorInfo) {
        this.authorInfo = authorInfo;
    }
    @ModelAttribute("authorInfo")
    public AuthorInfo addAuthorDataToModel(){
        return authorInfo;
    }
}
