package lt.kristina.blogapp.service;

import lombok.AllArgsConstructor;
import lt.kristina.blogapp.errors.PostNotFoundException;
import lt.kristina.blogapp.model.Post;
import lt.kristina.blogapp.repository.PostsRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@AllArgsConstructor
@Service
public class PostsService  {

    private final PostsRepository postsRepository;

    public Page<Post> getPosts(Pageable pageable) {
        return postsRepository.findAll(pageable);
    }

    public void createPost(Post post){

        UUID postId = UUID.randomUUID();
        post.setId(postId);

        postsRepository.save(post);
    }

    public Post getPost(UUID id) {

        return postsRepository.findById(id)
                .orElseThrow(() -> new PostNotFoundException("", null));
    }

    public void updatePost(Post post) {

        postsRepository.save(post);
    }

    public Post deletePost(UUID id) {

        Post postToRemove = getPost(id);
        postsRepository.delete(postToRemove);

        return postToRemove;
    }

    public List<Post> search (String name) {

        return postsRepository.findByNameContainingIgnoreCase(name);
    }
}
