package lt.kristina.blogapp.controller;

import lombok.AllArgsConstructor;

import lt.kristina.blogapp.errors.PostNotFoundException;
import lt.kristina.blogapp.model.Post;
import lt.kristina.blogapp.model.User;
import lt.kristina.blogapp.service.PostsService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.security.Principal;
import java.util.UUID;


@AllArgsConstructor
@Controller

public class PostsController {

    private final PostsService postsService;

    @GetMapping("/posts")
    public String getPosts(@PageableDefault(size = 3) Pageable pageable, Model model,
                           Principal principal, Authentication authentication, @AuthenticationPrincipal User user) {

        SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Page<Post> posts = postsService.getPosts(pageable);
        model.addAttribute("posts", posts);

        return "posts";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/posts/create")
    public String openPostForm(Model model) {

        model.addAttribute("post", new Post());
        return "postForm";
    }


    @PostMapping("/posts/create")
    public String createPost(@Valid Post post, BindingResult errors, RedirectAttributes redirectAttributes) {
        if(errors.hasErrors()){
            return "postForm";
        }
       postsService.createPost(post);

        redirectAttributes.addFlashAttribute("message",
                String.format("Post '%s' successfully created!", post.getName()));

        return "redirect:/posts";
    }
    @GetMapping("/posts/{id}")
    public String openPost(@PathVariable UUID id, Model model) {

        model.addAttribute("post", postsService.getPost(id));

        return "postForm";
    }

    @PostMapping("/posts/{id}")
    public String updatePost(Post post, Model model) {

        postsService.updatePost(post);

        model.addAttribute("message", String.format("Post '%s' successfully updated!", post.getName()));

        return "redirect:/posts";
    }

    @PostMapping("/posts/{id}/delete")
    public String deletePost(@PathVariable UUID id, RedirectAttributes redirectAttributes) {

        Post post = postsService.deletePost(id);

        redirectAttributes.addAttribute("message", String.format("Post '%s' successfully deleted!", post.getName()));

        return "redirect:/posts";
    }

    @GetMapping("/posts/search")
    public String search (@RequestParam(required = false) String name, Model model) {

        model.addAttribute("posts", postsService.search(name));

        return "posts";
    }

    @ExceptionHandler(PostNotFoundException.class)
    public String postNotFound(PostNotFoundException e, Model model) {

        model.addAttribute("messageCode", e.getMessage());
        model.addAttribute("postId", e.getPostId());

        return "error/postNotFoundPage";
    }
}
