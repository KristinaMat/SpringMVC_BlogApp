package lt.kristina.blogapp.model;

import lombok.*;

import org.hibernate.annotations.Type;
import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Collection;

import java.util.UUID;


@Data
@Entity
@NoArgsConstructor
public class Post {
    @Id
    @Type(type = "uuid-char")
    private UUID id;

    @NotBlank
    @Size(min=3,max=50)
    private String name;

    @NotNull
    @Size(max=255)
    private String body;

    @OneToMany(mappedBy = "post", fetch=FetchType.EAGER)
    private Collection<Comment> comments;


}
