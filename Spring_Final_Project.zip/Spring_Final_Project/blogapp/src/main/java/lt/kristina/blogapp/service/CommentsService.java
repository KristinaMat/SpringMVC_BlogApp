package lt.kristina.blogapp.service;

import lombok.AllArgsConstructor;
import lt.kristina.blogapp.errors.CommentNotFoundException;
import lt.kristina.blogapp.model.Comment;
import lt.kristina.blogapp.repository.CommentsRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.UUID;

@AllArgsConstructor
@Service
public class CommentsService {
    private final CommentsRepository commentsRepository;

    public Page<Comment> getComments(Pageable pageable) {
        return commentsRepository.findAll(pageable);
    }

    public void createComment(Comment comment){

        UUID commentId = UUID.randomUUID();
        comment.setId(commentId);

        commentsRepository.save(comment);
    }

    public Comment getComment(UUID id) {

        return commentsRepository.findById(id)
                .orElseThrow(() -> new CommentNotFoundException("", null));
    }

    public void updateComment(Comment comment) {

        commentsRepository.save(comment);
    }

    public Comment deleteComment(UUID id) {

        Comment commentToRemove = getComment(id);
        commentsRepository.delete(commentToRemove);

        return commentToRemove;
    }
}
