package lt.kristina.blogapp.controller;

import lombok.AllArgsConstructor;

import lt.kristina.blogapp.model.User;
import lt.kristina.blogapp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@AllArgsConstructor
@Controller
public class SignupController {

    private final UserService userService;

    @GetMapping("/signup")
    public String getRegisterForm(Model model){
        User user=new User();
        model.addAttribute("user", user);
        return "registerForm";
    }


    @PostMapping("/register")
    public String registerNewUser(User user, RedirectAttributes redirectAttributes){
        userService.createUser(user);
        redirectAttributes.addFlashAttribute("message",
                String.format("User '%s' successfully created!", user.getName()));

        return "redirect:/posts";
    }

}
