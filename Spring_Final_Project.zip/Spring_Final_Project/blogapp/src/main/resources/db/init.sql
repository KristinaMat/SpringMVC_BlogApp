INSERT INTO POST (ID, BODY, NAME) VALUES
('00000000-0000-0000-0000-000000000001','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Rose'),
('00000000-0000-0000-0000-000000000002','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Tulip'),
('00000000-0000-0000-0000-000000000003','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.','Lily'),
('00000000-0000-0000-0000-000000000004','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Bluebell'),
('00000000-0000-0000-0000-000000000005','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Calendula'),
('00000000-0000-0000-0000-000000000006','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Orchid'),
('00000000-0000-0000-0000-000000000007','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Daisy'),
('00000000-0000-0000-0000-000000000008','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.','Sunflowers'),
('00000000-0000-0000-0000-000000000009','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Iris');

INSERT INTO COMMENT (ID, BODY, POST_ID) VALUES
('00000001-0000-0000-0000-000000000000','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ','00000000-0000-0000-0000-000000000001'),
('00000002-0000-0000-0000-000000000000','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ','00000000-0000-0000-0000-000000000002'),
('00000003-0000-0000-0000-000000000000','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ','00000000-0000-0000-0000-000000000002'),
('00000004-0000-0000-0000-000000000000','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ','00000000-0000-0000-0000-000000000004'),
('00000005-0000-0000-0000-000000000000','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ','00000000-0000-0000-0000-000000000002'),
('00000006-0000-0000-0000-000000000000','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ','00000000-0000-0000-0000-000000000003'),
('00000007-0000-0000-0000-000000000000','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ','00000000-0000-0000-0000-000000000003');


INSERT INTO USERS (USERNAME, NAME, SURNAME, PASSWORD) VALUES
    ('user', 'Useris', 'Useriauskas','{bcrypt}$2a$12$GtVeSIV16y1OOBdYJES5HOIJkxWBLNKDlqqSt7iz0TVg0..XE3nb6'), /* password=pass */
    ('admin', 'Adminas', 'Adminiauskas', '{bcrypt}$2a$12$b8PbmpdeCXu5HOQPWDOmveN9TsX9T/czvtL5hOEAvpZM1.DFKjmEW'); /* password=admin */

INSERT INTO ROLE VALUES
    ('USER'),
    ('ADMIN');

INSERT INTO USERS_ROLES VALUES
    ('user', 'USER'),
    ('admin', 'USER'),
    ('admin', 'ADMIN');
